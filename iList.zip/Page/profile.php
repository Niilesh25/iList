<?php
session_start();
include("connection.php");
include("functions.php");
include("navbar.php");

// Check if the user is logged in
if (!isset($_SESSION['USERID'])) {
    header("Location: login.php");
    exit();
}

// Retrieve user details from the database based on the USERID
$userId = $_SESSION['USERID'];
$sql = "SELECT NAME, EMAIL, PASSWORD FROM customer WHERE UserID = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $userData = $result->fetch_assoc();
} else {
    echo "User not found.";
    exit(); // Exit the script if the user is not found
}

// Save edited user details to the database
if (isset($_POST['save'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Update the user details in the database
    $updateSql = "UPDATE customer SET NAME = ?, EMAIL = ?, PASSWORD = ? WHERE UserID = ?";
    $updateStmt = $con->prepare($updateSql);
    $updateStmt->bind_param("sssi", $name, $email, $password, $userId);
    $updateStmt->execute();

    // Refresh the page to see the updated user details
    header("Location: profile.php");
    exit();
}

// Logout
if (isset($_POST['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="profile.css">
    <title>Profile</title>
</head>

<body>
    <main>
        <div class="profile-picture-container">
            <img src="images/account.png">
        </div>
        <div class="info">
            <h2>Welcome, <?php echo isset($userData['NAME']) ? $userData['NAME'] : ''; ?></h2>
            <p><b>Name:</b> <?php echo isset($userData['NAME']) ? $userData['NAME'] : ''; ?></p>
            <p><b>Email:</b> <?php echo isset($userData['EMAIL']) ? $userData['EMAIL'] : ''; ?></p>
            <p><b>Password:</b> <?php echo isset($userData['PASSWORD']) ? $userData['PASSWORD'] : ''; ?></p>
            <form method="post">
                <button class="edit-button" name="edit">Edit</button>
                <button class="logout-button" name="logout">Logout</button>
            </form>
        </div>

        <?php
        if (isset($_POST['edit'])) {
        ?>
            <div class="edit-form">
                <h3>Edit Profile</h3>
                <form method="post">
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" value="<?php echo isset($userData['NAME']) ? $userData['NAME'] : ''; ?>" required>
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" value="<?php echo isset($userData['EMAIL']) ? $userData['EMAIL'] : ''; ?>" required>
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" value="<?php echo isset($userData['PASSWORD']) ? $userData['PASSWORD'] : ''; ?>" required>
                    <button class="save-button" name="save">Save</button>
                </form>
            </div>
        <?php
        }
        ?>
    </main>

</body>
    <!-- Footer-->
    <footer class="footer">
        <div class="container">
            <p class="m-0 text-center text-white">&copy; @Niilesh</p>
        </div>
    </footer>
</html>
