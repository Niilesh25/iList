<?php
session_start();

$_SESSION;
include_once 'connection.php';
include_once 'functions.php';

// Delete phone entry
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["delete"])) {
    $phoneId = $_POST["deletePhoneId"] ?? '';

    if (!empty($phoneId)) {
        // Delete the associated rows from the `bil` table (replace 'bil' with the actual child table name)
        $sql_delete_bil = "DELETE FROM `bil` WHERE `PHONEID` = '$phoneId'";
        $con->query($sql_delete_bil);

        // Then, delete the phone from the `phone` table
        $sql_delete_phone = "DELETE FROM `phone` WHERE `PHONEID` = '$phoneId'";
        if ($con->query($sql_delete_phone) === TRUE) {
            // Show success message using JavaScript alert
            echo "<script>alert('Phone Successfully Deleted');</script>";
        } else {
            echo "<script>alert('Failed to delete phone');</script>";
        }
    }
}

//Delete User Entry
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["delete"])) {
    $userId = $_POST["deleteUserId"] ?? '';

    if (!empty($userId)) { // Corrected the variable name here
        // Delete the associated rows from the `bil` table (replace 'bil' with the actual child table name)
        $sql_delete_bil = "DELETE FROM `bil` WHERE `USERID` = '$userId'";
        $con->query($sql_delete_bil);

        // Then, delete the user from the `customer` table (replace 'customer' with the actual table name)
        $sql_delete_user = "DELETE FROM `customer` WHERE `USERID` = '$userId'";
        if ($con->query($sql_delete_user) === TRUE) {
            // Show success message using JavaScript alert
            echo "<script>alert('User Account Successfully Deleted');</script>";
        } else {
            echo "<script>alert('Failed to delete user account');</script>";
        }
    }
}


if (isset($_POST["submit"])) {
    $productname = $_POST["productname"];
    $price = $_POST["price"];
    $brand = $_POST["brand"];
    $display_screen = $_POST["display_screen"];
    $storage = $_POST["storage"];

    // For upload photos
    $upload_dir = "uploads/"; // This is where the uploaded photo is stored
    $product_image = $upload_dir . $_FILES["imageUpload"]["name"];
    $upload_file = $upload_dir . basename($_FILES["imageUpload"]["name"]);
    $imageType = strtolower(pathinfo($upload_file, PATHINFO_EXTENSION)); // Used to detect the image format
    $check = $_FILES["imageUpload"]["size"]; // To detect the size of the image
    $upload_ok = 0;

    if (file_exists($upload_file)) {
        echo "<script>alert('This file already exists')</script>";
        $upload_file = 0;
    } else {
        $upload_ok = 1;
        if ($check !== false) {
            $upload_ok = 1;
        } else {
            echo '<script>alert("The photo size is 0. Please change the photo")</script>';
            $upload_ok = 0;
            if ($imageType == 'jpg' || $imageType == 'png' || $imageType == 'jpeg' || $imageType == 'gif') {
                $upload_ok = 1;
            } else {
                echo '<script>alert("Please change the image format");</script>';
                $upload_ok = 0;
            }
        }

        if ($upload_ok == 0) {
            echo '<script>alert("Sorry, your file didn\'t upload. Please try again.")</script>';
        } else {
            if ($productname !== "" && $price !== "") {
                if (move_uploaded_file($_FILES["imageUpload"]["tmp_name"], $upload_file)) {
                    $product_image = $upload_file;

                    // Generate a unique ID for the image
                    $imageID = uniqid();

                    // Insert the image into the `image` table
                    $sql = "INSERT INTO `image` (`IMAGEID`, `IMAGE`) VALUES ('$imageID', '$product_image')";
                    if ($con->query($sql) === TRUE) {
                        // Insert the data into the `phone` table
                        $sql1 = "INSERT INTO `phone` (`MODEL`, `PRICE`, `BRAND`, `DISPLAY_SCREEN`, `STORAGE`, `IMAGEID`) 
                        VALUES ('$productname', '$price', '$brand', '$display_screen', '$storage', '$imageID')";
                        if ($con->query($sql1) === TRUE) {
                            echo "<script>alert('Phone Successfully Added');</script>";
                        } else {
                            echo "<script>alert('Failed to insert data into the phone table');</script>";
                        }
                    } else {
                        echo "<script>alert('Failed to insert image into the database');</script>";
                    }
                } else {
                    echo "<script>alert('Failed to move the uploaded file');</script>";
                }
            }
        }
    }
}

// Fetch phone entries for dropdown menus
$phoneQuery = "SELECT `PHONEID`, `MODEL` FROM `phone`";
$phoneResult = $con->query($phoneQuery);

// Fetch user entries for dropdown menus
$userQuery = "SELECT `USERID`, `NAME` FROM `customer`"; // Replace 'users' with your actual user table name
$userResult = $con->query($userQuery);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="upload.css">
    <style>
        .section-label {
            margin-top: 20px;
            font-weight: bold;
        }

        .black-box {
            border: 2px solid black;
            padding: 10px;
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <?php include_once 'navbar.php'; ?>

    <div>
        <section id="upload_container">
            <div class="black-box">
                <p class="section-label">Phone Info</p>
                <form action="upload.php" method="POST" enctype="multipart/form-data">
                    <select name="phoneId" id="phoneId" onchange="displayPhoneDetails()">
                        <option value="">Select a Phone</option>
                        <?php while ($row = $phoneResult->fetch_assoc()): ?>
                            <option value="<?php echo $row['PHONEID']; ?>"><?php echo $row['MODEL']; ?></option>
                        <?php endwhile; ?>
                    </select>
                </form>
                <p id="phoneDetails"></p>
            </div>

            <div class="black-box">
                <p class="section-label">Upload Product</p>
                <form action="upload.php" method="POST" enctype="multipart/form-data">
                    <input type="text" name="productname" id="productname" placeholder="Product Name" required>
                    <input type="text" name="brand" id="brand" placeholder="Product Brand">
                    <input type="number" name="price" id="price" placeholder="Product Price" required>
                    <input type="text" name="display_screen" id="display_screen" placeholder="Display Screen" required>
                    <input type="text" name="storage" id="storage" placeholder="Storage" required>
                    <input type="file" name="imageUpload" id="imageUpload" required hidden>
                    <input type="submit" value="Upload" name="submit">
                </form>
            </div>

            <div class="black-box">
    <p class="section-label">Delete Phone</p>
    <form action="upload.php" method="POST">
        <select name="deletePhoneId" id="deletePhoneId">
            <option value="">Select a Phone to Delete</option>
            <?php mysqli_data_seek($phoneResult, 0); // Reset result pointer to the beginning ?>
            <?php while ($row = $phoneResult->fetch_assoc()): ?>
                <option value="<?php echo $row['PHONEID']; ?>"><?php echo $row['MODEL']; ?></option>
            <?php endwhile; ?>
        </select>
        <input type="submit" value="Delete" name="delete">
    </form>
</div>

<div class="black-box">
    <p class="section-label">Delete Account</p>
    <form action="upload.php" method="POST">
        <select name="deleteUserId" id="deleteUserId">
            <option value="">Select an Account to Delete</option>
            <?php mysqli_data_seek($userResult, 0); // Reset result pointer to the beginning ?>
            <?php while ($row = $userResult->fetch_assoc()): ?>
                <option value="<?php echo $row['USERID']; ?>"><?php echo $row['NAME']; ?></option>
            <?php endwhile; ?>
        </select>
        <input type="submit" value="Delete" name="delete">
    </form>
</div>



</div>

    <script>
        // Function to display phone details
        function displayPhoneDetails() {
            var phoneId = document.getElementById("phoneId").value;
            if (phoneId !== "") {
                // Fetch phone details using AJAX and update the display
                var xmlhttp = new XMLHttpRequest();
                xmlhttp.onreadystatechange = function () {
                    if (this.readyState === 4 && this.status === 200) {
                        document.getElementById("phoneDetails").innerHTML = this.responseText;
                    }
                };
                xmlhttp.open("GET", "getPhoneDetails.php?phoneId=" + phoneId, true);
                xmlhttp.send();
            } else {
                document.getElementById("phoneDetails").innerHTML = "";
            }
        }

        
    </script>

    <!-- Footer-->
    <footer class="footer">
        <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; @Niilesh</p>
        </div>
    </footer>

</body>

</html>
