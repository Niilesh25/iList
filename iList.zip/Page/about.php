<?php
session_start();

    $_SESSION;
    
    include("connection.php");
    include("functions.php");


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css" class="css">
    <title>About iList</title>
</head>
<body>
<?php include 'navbar.php' ?>
<style>
    h1{
        text-align: center;
        font size: 5cm;
    }
 </style>
<div class="container">
    <h1 >What is this Website?</h1>
</div>
<div class="about">
    <h3>
        iList is a Malaysia based Online Phone Shop 
</h3>
</div>
<!-- Footer-->
<footer class="footer">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; @Niilesh</p></div>
</footer>
</body>