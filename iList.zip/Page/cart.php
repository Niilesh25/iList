<?php
session_start();
include("connection.php");
include("functions.php");
include("navbar.php");

// Check if the user is logged in
if (!isset($_SESSION['USERID'])) {
    // If the user is not logged in, redirect to the login page
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['USERID'];

// Check if the LISTID parameter is passed to remove an item from the cart
if (isset($_GET['LISTID'])) {
    $cartId = $_GET['LISTID'];
    // Remove the item from the bil table
    $deleteSql = "DELETE FROM bil WHERE LISTID = ? AND USERID = ?";
    $deleteStmt = $con->prepare($deleteSql);
    $deleteStmt->bind_param("ii", $cartId, $userId);
    $deleteStmt->execute();
}

// Retrieve the cart items for the logged-in user
$cartSql = "SELECT b.LISTID, p.MODEL, p.BRAND, p.PRICE, i.image, b.QUANTITY,p.DISPLAY_SCREEN
            FROM bil b
            INNER JOIN phone p ON b.PHONEID = p.PHONEID
            INNER JOIN image i ON p.IMAGEID = i.IMAGEID
            WHERE b.USERID = ?";
$cartStmt = $con->prepare($cartSql);
$cartStmt->bind_param("i", $userId);
$cartStmt->execute();
$cartResult = $cartStmt->get_result();

// Calculate the total payment amount
$totalPayment = 0;

while ($cartRow = $cartResult->fetch_assoc()) {
    $cartId = $cartRow['LISTID'];
    $imageURL = $cartRow['image'];
    $model = $cartRow['MODEL'];
    $brand = $cartRow['BRAND'];
    $price = $cartRow['PRICE'];
    $quantity = $cartRow['QUANTITY'];
    $quantity = $cartRow['QUANTITY'];

    // Calculate item total
    $total = $price * $quantity;

    // Add item total to the total payment
    $totalPayment += $total;

    // Update the TOTAL and PAYMENT values in the bil table
    $updateSql = "UPDATE bil SET TOTAL = ?, PAYMENT = ? WHERE LISTID = ? AND USERID = ?";
    $updateStmt = $con->prepare($updateSql);
    $updateStmt->bind_param("ddii", $total, $totalPayment, $cartId, $userId);
    $updateStmt->execute();
}

?>

<!-- Your HTML and display logic here -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>iList</title>
    <link rel="stylesheet" href="cart.css">
    <style>
        @media print {
            .print-button,
            .action {
                display: none;
            }
            .remove-print {
                display: inline;
            }
        }
    </style>
</head>
<style>
    .cart-item {
        margin-bottom: 20px;
    }
</style>

<body>
    <!-- Display the cart items -->
    <main>
        <h3><?php echo mysqli_num_rows($cartResult); ?> Items</h3>
        <hr>
        <table>
            <tr>
                <th>Picture</th>
                <th>Brand</th>
                <th>Model</th>
                <th>Display</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total</th>
                <th class="action">Action</th>
            </tr>
            <?php
            $cartResult->data_seek(0); // Reset the result pointer to the beginning

            while ($cartRow = $cartResult->fetch_assoc()) {
                $cartId = $cartRow['LISTID'];
                $imageURL = $cartRow['image'];
                $model = $cartRow['MODEL'];
                $brand = $cartRow['BRAND'];
                $price = $cartRow['PRICE'];
                $quantity = $cartRow['QUANTITY'];
                // Check if the DISPLAY_SCREEN key exists in the $cartRow array
                $display = isset($cartRow['DISPLAY_SCREEN']) ? $cartRow['DISPLAY_SCREEN'] : 'N/A';

                // Calculate item total
                $total = $price * $quantity;
            ?>
                <tr class="cart-item">
                    <td><img src="<?php echo $imageURL; ?>" alt=""></td>
                    <td><?php echo $brand; ?></td>
                    <td><?php echo $model; ?></td>
                    <td><?php echo $display; ?></td>
                    <td>RM<?php echo $price; ?></td>
                    <td><?php echo $quantity; ?></td>
                    <td>RM<?php echo $total; ?></td>
                    <td class="action"><a href="cart.php?LISTID=<?php echo $cartId; ?>" class="remove remove-print">Remove</a></td>
                </tr>
            <?php
            }
            ?>
        </table>
        <div class="total">
            <p class="total-label">Total Payment: </p>
            <p class="total-amount">RM<?php echo $totalPayment; ?></p>
        </div>

        <!-- Add a print button -->
        <button class="print-button" onclick="printTable()">Print</button>
    </main>
    <script>
        // Function to print the table
        function printTable() {
            window.print();
        }
    </script>
</body>

</html>
