<?php
// getPhoneDetails.php

include_once 'connection.php';

if (isset($_GET["phoneId"])) {
    $phoneId = $_GET["phoneId"];

    // Fetch the phone details based on the selected phone ID
    $phoneDetailsQuery = "SELECT * FROM `phone` WHERE `PHONEID` = '$phoneId'";
    $phoneDetailsResult = $con->query($phoneDetailsQuery);

    if ($phoneDetailsResult->num_rows > 0) {
        $phoneDetails = $phoneDetailsResult->fetch_assoc();

        echo "Model: " . $phoneDetails['MODEL'] . "<br>";
        echo "Brand: " . $phoneDetails['BRAND'] . "<br>";
        echo "Display Screen: " . $phoneDetails['DISPLAY_SCREEN'] . "<br>";
        echo "Storage: " . $phoneDetails['STORAGE'] . "<br>";
    } else {
        echo "No phone details found";
    }
}
?>
