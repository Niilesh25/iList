<?php
session_start();

include("connection.php");
include("functions.php");

$login_successful = false;

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    // something was posted
    $NAME = $_POST['NAME'];
    $PASSWORD = $_POST['PASSWORD'];

    if (!empty($NAME) && !empty($PASSWORD) && !is_numeric($NAME)) {
        // read from database
        $query = "SELECT * FROM customer WHERE name = '$NAME' LIMIT 1";
        $result = mysqli_query($con, $query);

        if ($result && mysqli_num_rows($result) > 0) {
            $user_data = mysqli_fetch_assoc($result);

            if ($user_data['PASSWORD'] == $PASSWORD) {
                $_SESSION['USERID'] = $user_data['USERID']; // Update session variable name
                $login_successful = true;
            }
        }
    } else {
        echo "Please enter valid information";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Login</title>

    <style>
        /* Add the following CSS for the login button */
        #button {
            border: 2px solid black;
            padding: 1em;
            width: 80%;
            cursor: pointer;
            margin-top: 2em;
            font-weight: bold;
            position: relative;
            margin-top: 60px;
            transition: all 0.5s; /* Add transition property for all CSS changes */
        }

        #button::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            bottom: 0;
            width: 0;
            background-color: black;
            transition: all 0.5s;
            margin: 0;
        }

        #button::after {
            content: "";
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            width: 0;
            background-color: black;
            transition: all 0.5s;
        }

        #button:hover::before,
        #button:focus::before {
            width: 30%;
        }

        #button:hover::after,
        #button:focus::after {
            width: 30%;
        }

    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div id="box2" class="center-container">
        <form method="post">
            <div style="font-size: 20px;margin: 10px">Login</div>
            <div class="TextBox">
                <h5>Name:</h5>
                <input id="text" type="text" name="NAME"><br><br>
            </div>
            <h5>Password:</h5>
            <input id="text" type="password" name="PASSWORD"><br><br>

            <input id="button" type="submit" value="Login"><br><br>

            <a class="signup" href="signup.php">Sign Up</a><br><br>

            <?php if ($login_successful): ?>
                <script>
                    setTimeout(function() {
                        alert("Login Successful");
                        window.location.href = "index.php";
                    }); // Redirect after 2 seconds
                </script>
            <?php endif; ?>
        </form>
    </div>
</body>
<!-- Footer-->
<footer class="footer">
    <div class="container"><p class="m-0 text-center text-white">&copy; @Niilesh</p></div>
</footer>
</html>
