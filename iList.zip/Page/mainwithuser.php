<?php
session_start();

    $_SESSION;
    
    include("connection.php");
    include("functions.php");

    $user_data = check_login($con);

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="script.js" defer></script>
</head>
<body>
    <?php include 'navbar.php' ?>     
<style>
    h3{
        text-align: center;
        font size: 3cm;
    }
 </style>
<div class="container">
    <h3>Welcome, <?php echo $user_data['NAME']; ?></h3>
</div>

<div class="wrapper">
    <i id= "left" class="fa-solid fa-angle-left"></i>
        <div class="carousel">
            <img src="images/img.png" alt="img">
            <img src="images/img-2.jpg" alt="img">
            <img src="images/img-3.jpg" alt="img">
            <img src="images/img-4.jpeg" alt="img">
            <img src="images/img-5.jpg" alt="img">
            <img src="images/img-4.jpeg" alt="img">
        </div>
    <i id= "right" class="fa-solid fa-angle-right"></i>
    </div>

<div class="container">
  <div class="box">
    <img class="IPhone" src="images/IPhone.jpeg" alt="img">
    <li class="button"><a href="iphone.php">View IPhone</a></li>
  </div>
  <div class="box">
    <img class="SamPic" src="images/samsung.png" alt="img">
    <li class="button"><a href="samsung.php">View Samsung</a></li>
  </div>
  <div class="box">
    <img class="Oppo" src="images/IPhone.jpeg" alt="img">
    <li class="button"><a href="oppo.php">View Oppo</a></li>
  </div>
</div>
<!-- Footer-->
<footer class="footer">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; @Niilesh</p></div>
</footer>