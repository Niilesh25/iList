<?php
session_start();
include("connection.php");
include("functions.php");
include("navbar.php");

if (isset($_GET['id'])) {
    $phoneId = $_GET['id'];

    // Retrieve phone details from the database based on the PhoneID
    $sql = "SELECT p.MODEL, p.BRAND, p.PRICE, p.DISPLAY_SCREEN, p.STORAGE, i.image
            FROM phone p
            INNER JOIN image i ON p.IMAGEID = i.IMAGEID
            WHERE p.PHONEID = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $phoneId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $phoneData = $result->fetch_assoc();
        // Display the phone details
        $imageURL = $phoneData['image'];
    } else {
        echo "Phone not found.";
    }
} else {
    echo "Invalid PhoneID.";
}

if (isset($_POST['add_to_cart']) && isset($_POST['quantity'])) {
    // Check if the user is logged in
    if (isset($_SESSION['USERID'])) {
        $userId = $_SESSION['USERID'];
        $quantity = $_POST['quantity'];

        // Store the user ID, phone ID, and quantity in the bil table
        $insertSql = "INSERT INTO bil(USERID, PHONEID, QUANTITY) VALUES (?, ?, ?)";
        $insertStmt = $con->prepare($insertSql);
        $insertStmt->bind_param("iii", $userId, $phoneId, $quantity);
        $insertStmt->execute();

        // Redirect to the cart page
        header("Location: cart.php");
        exit();
    } else {
        // If the user is not logged in, redirect to the login page
        header("Location: login.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="phone.css">
    <title>Phone Details</title>
</head>

<body>
    <main>
        <div class="image-info">
            <img src="<?php echo $imageURL; ?>" alt="Phone Image">
        </div>
        <div class="info">
        <h2 class="largest-text"><?php echo $phoneData['MODEL']; ?></h2>
            <p class="brand">Brand: <?php echo $phoneData['BRAND']; ?></p>
            <p class="Price">Price: RM<?php echo $phoneData['PRICE']; ?></p>
            <p class="display">Display Screen: <?php echo $phoneData['DISPLAY_SCREEN']; ?></p>
            <p class="storage">Storage: <?php echo $phoneData['STORAGE']; ?></p>
            <form method="post">
            <div class="quantity-container">
                <label for="quantity" class="quantity-label">Quantity:</label>
                <input type="number" id="quantity" name="quantity" class="quantity-input" placeholder="Quantity" min="1" required>

            </div>
            <button class="add-to-cart-button" name="add_to_cart">
  <span>Add to Cart</span>
</button>
            </form>
        </div>
        <div class="product-container">
            <?php
            $sql = "SELECT p.*, i.IMAGE FROM phone p
                    INNER JOIN image i ON p.IMAGEID = i.IMAGEID";
            $result = $con->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
            ?>
                    <div class="card">
                        <div class="image">
                            <img src="<?php echo $row["IMAGE"]; ?>" alt="">
                        </div>
                        <div class="caption">
                            <p class="product_name"><?php echo $row["MODEL"]; ?></p>
                            <p class="brand"><b><?php echo $row["BRAND"]; ?></b></p>
                            <p class="price"><b>RM<?php echo $row["PRICE"]; ?></b></p>
                        </div>
                        <a class="add" href="phone.php?id=<?php echo $row['PHONEID']; ?>">View</a>
                    </div>
            <?php
                }
            } else {
                echo "<p>No phones available.</p>";
            }
            ?>
        </div>
    </main>
    <!-- Footer-->
    <footer class="footer">
        <div class="container">
            <p class="m-0 text-center text-white">&copy; @Niilesh</p>
        </div>
    </footer>
</body>

</html>
