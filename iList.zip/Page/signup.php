<?php
session_start();

include("connection.php");
include("functions.php");

$signin_successful = false; // Default value

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    // something was posted
    $NAME = $_POST['NAME'];
    $EMAIL = $_POST['EMAIL'];
    $PASSWORD = $_POST['PASSWORD'];

    if (!empty($NAME) && !empty($PASSWORD) && !is_numeric($NAME)) {
        // save to database
        $USERID = random_num(20);
        $query = "INSERT INTO customer (USERID, NAME, EMAIL, PASSWORD) VALUES ('$USERID', '$NAME', '$EMAIL', '$PASSWORD')";
        mysqli_query($con, $query);
        $signin_successful = true;
    } else {
        echo "Please enter some valid information";
    }
}

function random_num($length)
{
    $text = "";
    if($length < 5)
    {
        $length = 5;
    }

    $len = rand(4,$length);

    for ($i=0; $i < $len ; $i++)
    {
        $text .= rand(0,9);
    }

    return $text;
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">

    <style>
        /* Add the following CSS */
        #box3 {
            width: 50%;
            margin: 0 auto;
            /* Center the box horizontally */
            padding: 20px;
            align-items: center;
            text-align: center;
            justify-content: center;
            display: flex;
            flex-direction: column;
            /* Align items vertically */
        }

        #box3 #button {
            border: 2px solid black;
            padding: 1em;
            width: 80%;
            cursor: pointer;
            margin-top: 2em;
            font-weight: bold;
            position: relative;
            margin-top: 60px;
            transition: all 0.5s;
            /* Add transition property for all CSS changes */
        }

        #box3 #button::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            bottom: 0;
            width: 0;
            background-color: black;
            transition: all 0.5s;
            margin: 0;
        }

        #box3 #button::after {
            content: "";
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            width: 0;
            background-color: black;
            transition: all 0.5s;
        }

        #box3 #button:hover::before,
        #box3 #button:focus::before {
            width: 30%;
        }

        #box3 #button:hover::after,
        #box3 #button:focus::after {
            width: 30%;
        }
    </style>

    <title>SignUp</title>
</head>

<body>
    <?php include 'navbar.php' ?>

    <div id="box3">
        <form method="post">
            <h3>
                Join the IList Community
            </h3>
            <div style="font-size: 20px;margin: 10px">SignUp</div>
            <h5>Email:</h5>
            <input id="text" type="text" name="EMAIL"><br><br>
            <h5>Name:</h5>
            <input id="text" type="text" name="NAME"><br><br>
            <h5>Password:</h5>
            <input id="text" type="password" name="PASSWORD"><br><br>

            <input id="button" type="submit" value="Signup"><br><br>


            <a href="login.php">Login</a><br><br>

            <?php if ($signin_successful): ?>
                <script>
                    setTimeout(function() {
                        alert("Account Successfully Created");
                        window.location.href = "login.php";
                    }); // Redirect after 3 seconds
                </script>
            <?php endif; ?>
        </form>

    </div>
</body>
<!-- Footer-->
<footer class="footer">
    <div class="container"><p class="m-0 text-center text-white">&copy; @Niilesh</p></div>
</footer>
</html>

