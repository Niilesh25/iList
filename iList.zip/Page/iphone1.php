<?php
include("connection.php");
include("functions.php");

$sql = "SELECT p.*, i.IMAGE FROM phone p
        INNER JOIN image i ON p.IMAGEID = i.IMAGEID
        WHERE p.BRAND = 'IPhone'";
$result = $con->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="iphone.css">
    <title>iPhones</title>
</head>

<body>
    <?php include_once 'navbar.php'; ?>

    <main>
        <h2>
            iPhones
        </h2>
        <div class="product-container">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
            ?>
                    <div class="card">
                        <div class="image">
                            <img src="<?php echo $row["IMAGE"]; ?>" alt="">
                        </div>
                        <div class="caption">
                            <p class="product_name"><?php echo $row["MODEL"]; ?></p>
                            <p class="brand"><b><?php echo $row["BRAND"]; ?></b></p>
                            <p class="price"><b>RM<?php echo $row["PRICE"]; ?></b></p>
                        </div>
                        <a class="add" href="phone.php?id=<?php echo $row['PHONEID']; ?>">View</a>
                    </div>
            <?php
                }
            } else {
                echo "<p>No iPhones available.</p>";
            }
            ?>
        </div>
    </main>
</body>
<!-- Footer-->
<footer class="footer">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; @Niilesh</p></div>
</footer>
</html>
