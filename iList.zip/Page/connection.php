<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "ilsit";

if (!$con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname)) {
    die("Failed to connect!");
}

if (isset($_GET["id"])) {
    $PHONEID = mysqli_real_escape_string($con, $_GET["id"]);
    $sql = "SELECT * FROM bil WHERE PHONEID = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $PHONEID);
    $stmt->execute();
    $result = $stmt->get_result();

    $total_cart = "SELECT * FROM bil";
    $total_cart_result = $con->query($total_cart);
    $cart_num = mysqli_num_rows($total_cart_result);

    if (mysqli_num_rows($result) > 0) {
        $in_cart = "already in cart";
    } else {
        if (isset($_SESSION['USERID'], $_GET['userid'], $_GET['listid'])) {
            $insert = "INSERT INTO bil(PHONEID, UserID, LISTID) VALUES(?, ?, ?)";
            $stmt = $con->prepare($insert);
            $stmt->bind_param("iis", $PHONEID, $_GET['userid'], $_GET['listid']);
            if ($stmt->execute()) {
                $in_cart = "added into cart";
                
            } else {
                
            }
        } else {
            
        }
    }
}

if (isset($_GET["remove"])) {
    $PHONEID = $_GET["remove"];
    $sql = "DELETE FROM bil WHERE PHONEID = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $PHONEID);

    if ($stmt->execute()) {
        echo "Removed from cart";
    }
}
?>

