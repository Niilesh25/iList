<?php
function check_login($con)
{
    if (isset($_SESSION['USERID'])) {
        $id = $_SESSION['USERID'];
        $query = "SELECT * FROM customer WHERE USERID = ?";
        $stmt = $con->prepare($query);
        $stmt->bind_param("s", $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && mysqli_num_rows($result) > 0) {
            $user_data = mysqli_fetch_assoc($result);
            return $user_data;
        }
    }

    // Redirect to login
    header("Location: login.php");
    die;
}
?>
